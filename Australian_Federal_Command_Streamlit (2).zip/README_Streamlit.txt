AUSTRALIAN FEDERAL COMMAND — STREAMLIT PORT

Files:
- Australian_Federal_Command_Streamlit.py — Streamlit version of the game.
- requirements.txt — Streamlit dependency.

Run:
  pip install -r requirements.txt
  streamlit run Australian_Federal_Command_Streamlit.py

The simulation/economy/event mechanics are retained from the supplied 3,940-line source. Tkinter's desktop event loop and synchronous message boxes are replaced by Streamlit session-state interactions so buttons and dialogs survive Streamlit reruns.
