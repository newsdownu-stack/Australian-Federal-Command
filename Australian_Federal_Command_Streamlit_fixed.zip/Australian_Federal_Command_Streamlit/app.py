import streamlit as st
import streamlit.components.v1 as components
from pathlib import Path

st.set_page_config(page_title='Australian Federal Command', layout='wide', initial_sidebar_state='collapsed')

html_path = Path(__file__).with_name('game.html')
html = html_path.read_text(encoding='utf-8')

components.html(html, height=1600, scrolling=True)
