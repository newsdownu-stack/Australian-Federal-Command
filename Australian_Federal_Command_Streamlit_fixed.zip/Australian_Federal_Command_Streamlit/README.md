# Australian Federal Command — Streamlit

Run locally:

```bash
pip install -r requirements.txt
streamlit run app.py
```

The game runs inside a Streamlit HTML component so the browser-side buttons and interactions execute normally.

The initial displayed statistics match the latest MU/Python game's starting values:
- Debt: $978.7B AUD
- Inflation: 2.8%
- Unemployment: 4.0%
- Happiness: 72%
- Power bills: $120/mo
- Foreign relations: 100%
- Average interest rate: 6.2%
- Infrastructure Levy: 0%
- Pine Gap: pre-existing; not buildable
